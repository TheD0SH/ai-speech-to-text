=====================================
   VOICE TYPE - Easy Speech to Text
=====================================

HOW TO INSTALL:
1. Copy "VoiceType.exe" to your Desktop
2. That's it! No installation needed.


HOW TO USE:
1. Double-click VoiceType.exe to start
2. It will appear in your system tray (bottom-right corner near the clock)
3. HOLD DOWN the SHIFT key and speak
4. RELEASE the SHIFT key to transcribe
5. The text will be typed automatically!


FIRST TIME SETUP:
1. Right-click the tray icon (green microphone near clock)
2. Click "Settings"
3. Click "Get API Key" - this opens a website
4. Create a free account and copy your API key
5. Paste the key in Settings and click "Save"


TIPS:
- Speak clearly for best results
- Works in any app (email, Word, browser, etc.)
- Right-click tray icon to quit the program


NEED HELP?
Get your free API key at: https://console.groq.com/keys